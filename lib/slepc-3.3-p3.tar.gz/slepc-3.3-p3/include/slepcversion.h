#if !defined(__SLEPCVERSION_H)
#define __SLEPCVERSION_H

#define SLEPC_VERSION_RELEASE    1
#define SLEPC_VERSION_MAJOR      3
#define SLEPC_VERSION_MINOR      3
#define SLEPC_VERSION_SUBMINOR   0
#define SLEPC_VERSION_PATCH      3
#define SLEPC_VERSION_DATE       "August 3, 2012"
#define SLEPC_VERSION_PATCH_DATE "October 2, 2012"

#if !defined (SLEPC_VERSION_SVN)
#define SLEPC_VERSION_SVN        "unknown"
#endif

#if !defined(SLEPC_VERSION_DATE_SVN)
#define SLEPC_VERSION_DATE_SVN   "unknown"
#endif

#define SLEPC_VERSION_(MAJOR,MINOR,SUBMINOR) \
 ((SLEPC_VERSION_MAJOR == (MAJOR)) &&       \
  (SLEPC_VERSION_MINOR == (MINOR)) &&       \
  (SLEPC_VERSION_SUBMINOR == (SUBMINOR)) && \
  (SLEPC_VERSION_RELEASE  == 1))

#endif

