!
!  Single Fortran include file for all of PETSc
!

#include "finclude/petscsys.h"
#include "finclude/petscdraw.h"
#include "finclude/petscviewer.h"
#include "finclude/petscis.h"
#include "finclude/petscvec.h"
#include "finclude/petscmat.h"
#include "finclude/petscpc.h"
#include "finclude/petscpcmg.h"
#include "finclude/petscksp.h"
#include "finclude/petscsnes.h"
#include "finclude/petscdm.h"
#include "finclude/petscdmda.h"
!#include "finclude/petscdmadda.h"
!#include "finclude/petscdmcomposite.h"
#include "finclude/petscdmmesh.h"
!#include "finclude/petscdmsliced.h"
#include "finclude/petscts.h"
