!
!  Single Fortran include file for all of PETSc
!

#include "finclude/petscsysdef.h"
#include "finclude/petscdrawdef.h"
#include "finclude/petscviewerdef.h"
#include "finclude/petscbagdef.h"
#include "finclude/petscisdef.h"
#include "finclude/petscvecdef.h"
#include "finclude/petscmatdef.h"
#include "finclude/petscdmdef.h"
#include "finclude/petscdmdadef.h"
#include "finclude/petscdmmeshdef.h"
#include "finclude/petscpcdef.h"
#include "finclude/petsckspdef.h"
#include "finclude/petscsnesdef.h"
#include "finclude/petsctsdef.h"
