#ifndef included_ALE_ALE_hh
#define included_ALE_ALE_hh

#include <petscsys.h>

#ifndef  included_ALE_exception_hh
#include <sieve/ALE_exception.hh>
#endif
#ifndef  included_ALE_mem_hh
#include <sieve/ALE_mem.hh>
#endif
#ifndef  included_ALE_log_hh
#include <sieve/ALE_log.hh>
#endif
#ifndef  included_ALE_containers_hh
#include <sieve/ALE_containers.hh>
#endif
//#ifndef  included_ALE_args_hh
//#include <ALE_args.hh>
//#endif


#endif
