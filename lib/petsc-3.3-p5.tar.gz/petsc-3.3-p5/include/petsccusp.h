#if !defined(__PETSCCUSP_H)
#define __PETSCCUSP_H
/*
    This should only be included in user code that uses CUSP directly and hence the file name ends with .cu
*/
#include "../src/vec/vec/impls/dvecimpl.h"
#include "../src/vec/vec/impls/seq/seqcusp/cuspvecimpl.h"
#endif
